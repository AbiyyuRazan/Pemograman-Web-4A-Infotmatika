<?php
// ============================================
// pages/admin/ruangan.php — CRUD Ruangan (Perfect Spacing Edition)
// ============================================
session_start();
require_once '../../config/koneksi.php';
require_once '../../includes/functions.php';
wajibAdmin();

$judul_halaman = 'Kelola Ruangan';
$halaman_aktif = 'ruangan';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = bersihkan($_POST['nama_ruangan'] ?? '');
    $kapasitas = (int)($_POST['kapasitas'] ?? 0);
    $id        = (int)($_POST['id_ruangan'] ?? 0);

    if (empty($nama))    $errors[] = 'Nama ruangan wajib diisi.';
    if ($kapasitas <= 0) $errors[] = 'Kapasitas harus lebih dari 0.';

    if (empty($errors)) {
        if ($id > 0) {
            mysqli_query($koneksi, "UPDATE ruangan SET nama_ruangan='$nama', kapasitas=$kapasitas WHERE id_ruangan=$id");
            redirectDenganPesan('ruangan.php', 'Ruangan berhasil diperbarui!');
        } else {
            mysqli_query($koneksi, "INSERT INTO ruangan (nama_ruangan, kapasitas) VALUES ('$nama', $kapasitas)");
            redirectDenganPesan('ruangan.php', 'Ruangan berhasil ditambahkan!');
        }
    }
}

if (isset($_GET['aksi']) && $_GET['aksi'] === 'hapus') {
    $id = (int)$_GET['id'];
    $cek = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM event WHERE id_ruangan=$id"));
    if ($cek['total'] > 0) {
        redirectDenganPesan('ruangan.php', 'Ruangan tidak bisa dihapus karena masih digunakan!', 'error');
    }
    mysqli_query($koneksi, "DELETE FROM ruangan WHERE id_ruangan=$id");
    redirectDenganPesan('ruangan.php', 'Ruangan berhasil dihapus.');
}

$edit_data = null;
if (isset($_GET['aksi']) && $_GET['aksi'] === 'edit') {
    $edit_data = mysqli_fetch_assoc(mysqli_query($koneksi,
        "SELECT * FROM ruangan WHERE id_ruangan=" . (int)$_GET['id']));
}

$list_ruangan = mysqli_query($koneksi,
    "SELECT r.*, COUNT(e.id_event) as jumlah_event
     FROM ruangan r
     LEFT JOIN event e ON r.id_ruangan = e.id_ruangan
     GROUP BY r.id_ruangan
     ORDER BY r.nama_ruangan"
);
?>
<?php include '../../includes/header.php'; ?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --royal-blue: #1d4ed8;       
        --deep-blue: #1e40af;        
        --bg-dashboard: #f8fafc;     
        --text-dark: #0f172a;        
        --text-muted: #64748b;       
        --border-color: #e2e8f0;     
    }

    body { background-color: var(--bg-dashboard); margin: 0; }
    .app-wrapper { background-color: var(--bg-dashboard); min-height: 100vh; display: flex; }
    .main-content { margin-left: 260px; width: calc(100% - 260px); padding: 60px 40px 40px 40px; background-color: var(--bg-dashboard); min-height: 100vh; box-sizing: border-box; transition: all 0.3s ease; }
    .main-content * { box-sizing: border-box; font-family: 'Inter', sans-serif; }
    .topbar { display: flex; justify-content: space-between; align-items: center; padding-bottom: 24px; margin-bottom: 36px; border-bottom: 2px solid var(--border-color); background: transparent; }
    .topbar-judul { font-size: 28px; font-weight: 800; color: var(--text-dark); letter-spacing: -0.75px; line-height: 1.2; }
    .topbar-sub { font-size: 14px; color: var(--text-muted); margin-top: 6px; font-weight: 500; }
    .btn-menu { display: none; background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-dark); margin-right: 14px; padding: 0; }
    .alert-error { background-color: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; padding: 14px 18px; border-radius: 12px; font-size: 13.5px; font-weight: 500; margin-bottom: 24px; }
    .grid-container { display: grid; grid-template-columns: 340px 1fr; gap: 28px; align-items: start; }
    .card { background: #ffffff; border: 1px solid var(--border-color); border-radius: 16px; padding: 24px; box-shadow: 0 4px 10px rgba(15, 23, 42, 0.01); }
    .card-header-inline { display: flex; align-items: center; gap: 10px; margin-bottom: 24px; }
    .card-judul-inline { margin: 0; font-size: 16px; font-weight: 700; color: var(--text-dark); }
    .form-grup { margin-bottom: 20px; }
    .form-grup label { display: block; font-size: 13px; font-weight: 600; color: var(--text-dark); margin-bottom: 8px; }
    .input-premium { width: 100%; height: 42px; padding: 0 16px; font-size: 14px; border-radius: 10px; border: 1px solid var(--border-color); color: var(--text-dark); background-color: #ffffff; transition: all 0.2s ease; }
    .input-premium:focus { outline: none; border-color: var(--royal-blue); box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.15); }
    .btn-utama-premium { display: inline-flex; align-items: center; justify-content: center; gap: 8px; height: 42px; padding: 0 24px; background: linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%); color: #ffffff; text-decoration: none; font-size: 14px; font-weight: 600; border-radius: 10px; border: none; box-shadow: 0 4px 14px rgba(29, 78, 216, 0.25); transition: all 0.2s ease; cursor: pointer; white-space: nowrap; }
    .btn-utama-premium:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(29, 78, 216, 0.35); }
    .btn-batal-premium { display: inline-flex; align-items: center; justify-content: center; height: 42px; padding: 0 20px; background: #f1f5f9; color: #475569; text-decoration: none; font-size: 14px; font-weight: 600; border-radius: 10px; transition: all 0.2s; }
    .btn-batal-premium:hover { background: #e2e8f0; color: #1e293b; }
    .tabel-wrapper { overflow-x: auto; }
    .tabel-wrapper table { width: 100%; border-collapse: collapse; text-align: left; }
    .tabel-wrapper th { font-size: 11px; font-weight: 700; text-transform: uppercase; color: var(--text-muted); padding: 12px 14px; letter-spacing: 0.5px; border-bottom: 1px solid #f1f5f9; }
    .tabel-wrapper td { padding: 16px 14px; font-size: 13.5px; color: var(--text-dark); border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
    .tabel-wrapper tr:last-child td { border-bottom: none; }
    .tabel-wrapper tbody tr:hover { background-color: #f8fafc; }
    .badge-info-premium { background-color: #e0f2fe; color: #0369a1; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
    .btn-aksi { width: 34px; height: 34px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; text-decoration: none; transition: all 0.2s ease; font-size: 13px; border: none; cursor: pointer; }
    .btn-edit { background: #eff6ff; color: #2563eb; }
    .btn-edit:hover { background: #2563eb; color: white; }
    .btn-hapus { background: #fef2f2; color: #ef4444; }
    .btn-hapus:hover { background: #ef4444; color: white; }

    @media (max-width: 1024px) { .main-content { margin-left: 0; width: 100%; padding: 40px 24px 24px 24px; } .btn-menu { display: block; } .grid-container { grid-template-columns: 1fr; gap: 24px; } }
</style>

<div class="app-wrapper">
    <div id="sidebarOverlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:90"></div>
    <?php include '../../includes/sidebar_admin.php'; ?>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-kiri" style="display:flex; align-items:center;">
                <button class="btn-menu" id="btnMenu">☰</button>
                <div>
                    <div class="topbar-judul">Kelola Ruangan</div>
                    <div class="topbar-sub">Atur operasional, kapasitas, dan alokasi tempat kegiatan internal</div>
                </div>
            </div>
        </div>

        <div class="page-content">
            <?php tampilkanFlash(); ?>
            <?php if (!empty($errors)): ?>
                <div class="alert-error"><?= implode('<br>', $errors) ?></div>
            <?php endif; ?>

            <div class="grid-container">
                <div class="card">
                    <div class="card-header-inline">
                        <span style="font-size: 16px;"><?= $edit_data ? '✏️' : '➕' ?></span>
                        <h3 class="card-judul-inline"><?= $edit_data ? 'Edit Data Ruangan' : 'Tambah Ruangan Baru' ?></h3>
                    </div>
                    
                    <form method="POST">
                        <?php if ($edit_data): ?>
                            <input type="hidden" name="id_ruangan" value="<?= $edit_data['id_ruangan'] ?>">
                        <?php endif; ?>
                        
                        <div class="form-grup">
                            <label>Nama Ruangan *</label>
                            <input type="text" class="input-premium" name="nama_ruangan" required placeholder="Contoh: Aula Utama" value="<?= htmlspecialchars($edit_data['nama_ruangan'] ?? '') ?>">
                        </div>
                        
                        <div class="form-grup">
                            <label>Kapasitas (orang) *</label>
                            <input type="number" class="input-premium" name="kapasitas" min="1" required placeholder="Contoh: 150" value="<?= htmlspecialchars($edit_data['kapasitas'] ?? '') ?>">
                        </div>
                        
                        <div class="form-actions" style="display:flex; gap:10px; margin-top: 24px;">
                            <button type="submit" class="btn-utama-premium" style="flex: 1;">
                                <span><?= $edit_data ? 'Simpan Data' : 'Tambah Ruangan' ?></span>
                            </button>
                            <?php if ($edit_data): ?>
                                <a href="ruangan.php" class="btn-batal-premium">Batal</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>

                <div class="card">
                    <div class="card-header-inline">
                        <span style="font-size: 16px;">🏛️</span>
                        <h3 class="card-judul-inline">Daftar Tempat & Kapasitas</h3>
                    </div>
                    
                    <div class="tabel-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th style="width: 70px; text-align: center;">No</th>
                                    <th>Nama Ruangan</th>
                                    <th>Kapasitas</th>
                                    <th>Status Alokasi</th>
                                    <th style="width: 120px; text-align: center;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($list_ruangan) === 0): ?>
                                    <tr>
                                        <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">Belum ada lokasi ruangan yang terdaftar.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php $no = 1; while ($row = mysqli_fetch_assoc($list_ruangan)): ?>
                                    <tr>
                                        <td style="text-align: center; font-weight: 600; color: var(--text-muted);"><?= $no++ ?></td>
                                        <td><div style="font-weight: 600; color: var(--text-dark);"><?= htmlspecialchars($row['nama_ruangan']) ?></div></td>
                                        <td><div style="font-weight: 500; color: var(--text-dark);"><?= number_format($row['kapasitas']) ?> orang</div></td>
                                        <td><span class="badge-info-premium"><?= $row['jumlah_event'] ?> Event Terdaftar</span></td>
                                        <td>
                                            <div style="display: flex; gap: 8px; justify-content: center;">
                                                <a href="?aksi=edit&id=<?= $row['id_ruangan'] ?>" class="btn-aksi btn-edit" title="Modifikasi Tempat">✏️</a>
                                                <a href="#" onclick="konfirmasiHapus('?aksi=hapus&id=<?= $row['id_ruangan'] ?>', '<?= htmlspecialchars($row['nama_ruangan']) ?>')" class="btn-aksi btn-hapus" title="Hapus Lokasi">🗑️</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
    // FUNGSI KONFIRMASI HAPUS AMAN
    function konfirmasiHapus(url, namaData) {
        if (confirm("Apakah Anda yakin ingin menghapus \"" + namaData + "\"? Tindakan ini tidak dapat dibatalkan.")) {
            window.location.href = url;
        }
    }

    const btnMenu = document.getElementById('btnMenu');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if(btnMenu && sidebar && overlay) {
        btnMenu.addEventListener('click', () => { sidebar.style.transform = 'translateX(0)'; sidebar.style.left = '0'; overlay.style.display = 'block'; });
        overlay.addEventListener('click', () => { sidebar.style.transform = 'translateX(-100%)'; overlay.style.display = 'none'; });
    }
</script>
<?php include '../../includes/footer.php'; ?>