<?php
// ============================================
// pages/admin/kategori.php — Kelola Kategori Event (Perfect Spacing Edition)
// ============================================
session_start();
require_once '../../config/koneksi.php';
require_once '../../includes/functions.php';
wajibAdmin();

$judul_halaman = 'Kelola Kategori';
$halaman_aktif = 'kategori';
$admin_org = $_SESSION['organisasi'] ?? 'Pusat';

// Variabel untuk mode edit
$is_edit = false;
$id_edit = 0;
$nama_kategori_val = '';

// 1. PROSES TAMBAH / UPDATE KATEGORI
if (isset($_POST['simpan_kategori'])) {
    $nama_kategori = bersihkan($_POST['nama_kategori'] ?? '');
    $id_kategori   = (int)($_POST['id_kategori'] ?? 0);

    if (empty($nama_kategori)) {
        redirectDenganPesan('kategori.php', 'Nama kategori tidak boleh kosong!', 'error');
    }

    if ($id_kategori > 0) {
        $query = "UPDATE kategori_event SET nama_kategori = '$nama_kategori' WHERE id_kategori = $id_kategori";
        if (mysqli_query($koneksi, $query)) {
            redirectDenganPesan('kategori.php', 'Kategori berhasil diperbarui!');
        } else {
            redirectDenganPesan('kategori.php', 'Gagal memperbarui kategori.', 'error');
        }
    } else {
        $query = "INSERT INTO kategori_event (nama_kategori) VALUES ('$nama_kategori')";
        if (mysqli_query($koneksi, $query)) {
            redirectDenganPesan('kategori.php', 'Kategori baru berhasil ditambahkan!');
        } else {
            redirectDenganPesan('kategori.php', 'Gagal menambahkan kategori.', 'error');
        }
    }
}

// 2. AMBIL DATA UNTUK MODE EDIT
if (isset($_GET['aksi']) && $_GET['aksi'] === 'edit') {
    $id_edit = (int)$_GET['id'];
    $res_edit = mysqli_query($koneksi, "SELECT * FROM kategori_event WHERE id_kategori = $id_edit");
    if (mysqli_num_rows($res_edit) > 0) {
        $data_edit = mysqli_fetch_assoc($res_edit);
        $nama_kategori_val = $data_edit['nama_kategori'];
        $is_edit = true;
    }
}

// 3. PROSES HAPUS KATEGORI
if (isset($_GET['aksi']) && $_GET['aksi'] === 'hapus') {
    $id = (int)$_GET['id'];
    $cek_relasi = mysqli_query($koneksi, "SELECT id_event FROM event WHERE id_kategori = $id LIMIT 1");
    if (mysqli_num_rows($cek_relasi) > 0) {
        redirectDenganPesan('kategori.php', 'Gagal! Kategori ini masih digunakan oleh beberapa event.', 'error');
    } else {
        mysqli_query($koneksi, "DELETE FROM kategori_event WHERE id_kategori = $id");
        redirectDenganPesan('kategori.php', 'Kategori berhasil dihapus.');
    }
}

// 4. PENCARIAN & PAGINATION
$cari        = bersihkan($_GET['cari'] ?? '');
$per_halaman = 10;
$hal_ini     = max(1, (int)($_GET['hal'] ?? 1));
$offset      = ($hal_ini - 1) * $per_halaman;

$where = "";
if ($cari) {
    $where = "WHERE nama_kategori LIKE '%$cari%'";
}

$total_rows = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kategori_event $where"))['total'];
$total_hal  = ceil($total_rows / $per_halaman);

$list_kategori = mysqli_query($koneksi, 
    "SELECT * FROM kategori_event 
     $where 
     ORDER BY nama_kategori ASC 
     LIMIT $per_halaman OFFSET $offset"
);
?>
<?php include '../../includes/header.php'; ?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --royal-blue: #1d4ed8;       
        --deep-blue: #1e40af;        
        --bg-dashboard: #f8fafc;     
        --text-dark: #0f172a;        
        --text-muted: #64748b;       
        --border-color: #e2e8f0;     
    }

    /* OVERRIDE & RESET CONTAINER UTAMA STYLING */
    body {
        background-color: var(--bg-dashboard);
        margin: 0;
    }

    .app-wrapper {
        background-color: var(--bg-dashboard);
        min-height: 100vh;
        display: flex;
    }

    .main-content {
        margin-left: 260px; 
        width: calc(100% - 260px);
        padding: 60px 40px 40px 40px; 
        background-color: var(--bg-dashboard);
        min-height: 100vh;
        box-sizing: border-box;
        transition: all 0.3s ease;
    }

    .main-content * {
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    /* --- TOPBAR AREA --- */
    .topbar {
        display: flex;
        justify-content: space-between;
        align-items: center; 
        padding-bottom: 24px; 
        margin-bottom: 36px;  
        border-bottom: 2px solid var(--border-color); 
        background: transparent;
    }

    .topbar-judul {
        font-size: 28px; 
        font-weight: 800; 
        color: var(--text-dark);
        letter-spacing: -0.75px;
        line-height: 1.2;
    }

    .topbar-sub {
        font-size: 14px;
        color: var(--text-muted);
        margin-top: 6px;
        font-weight: 500;
    }

    .btn-menu {
        display: none;
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: var(--text-dark);
        margin-right: 14px;
        padding: 0;
    }

    /* --- CARD CONTAINER PREMIUM --- */
    .card {
        background: #ffffff;
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 24px;
        box-shadow: 0 4px 10px rgba(15, 23, 42, 0.01);
        margin-bottom: 32px;
    }

    .card-header-inline {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
    }

    .card-judul-inline {
        margin: 0; 
        font-size: 16px; 
        font-weight: 700; 
        color: var(--text-dark);
    }

    /* --- COMPONENTS INPUT & BUTTONS SYSTEM --- */
    .form-group-premium {
        display: flex;
        gap: 12px;
        align-items: center;
        max-width: 650px;
    }

    .cari-filter {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
    }

    .input-cari, .input-premium {
        height: 42px;
        padding: 0 16px;
        font-size: 14px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        color: var(--text-dark);
        background-color: #ffffff;
        transition: all 0.2s ease;
    }

    .input-cari {
        width: 320px;
    }

    .input-premium {
        flex: 1;
    }

    .input-cari:focus, .input-premium:focus {
        outline: none;
        border-color: var(--royal-blue);
        box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.15);
    }

    .btn-utama-premium {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        height: 42px;
        padding: 0 24px;
        background: linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%);
        color: #ffffff;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px; 
        border: none;
        box-shadow: 0 4px 14px rgba(29, 78, 216, 0.25);
        transition: all 0.2s ease;
        cursor: pointer;
        white-space: nowrap;
    }

    .btn-utama-premium:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(29, 78, 216, 0.35);
    }

    .btn-batal-premium {
        display: inline-flex;
        align-items: center;
        height: 42px;
        padding: 0 20px;
        background: #f1f5f9;
        color: #475569;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px;
        transition: all 0.2s;
    }

    .btn-batal-premium:hover {
        background: #e2e8f0;
        color: #1e293b;
    }

    /* --- TABEL PRESET SYSTEM --- */
    .tabel-wrapper {
        overflow-x: auto;
    }

    .tabel-wrapper table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
    }

    .tabel-wrapper th {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-muted);
        padding: 12px 14px;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #f1f5f9;
    }

    .tabel-wrapper td {
        padding: 16px 14px;
        font-size: 13.5px;
        color: var(--text-dark);
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
    }

    .tabel-wrapper tr:last-child td {
        border-bottom: none;
    }

    .tabel-wrapper tbody tr:hover {
        background-color: #f8fafc;
    }

    /* ACTION ROUNDED BUTTONS DESIGN */
    .btn-aksi {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.2s ease;
        font-size: 13px;
        border: none;
        cursor: pointer;
    }
    .btn-edit { background: #eff6ff; color: #2563eb; }
    .btn-edit:hover { background: #2563eb; color: white; }
    .btn-hapus { background: #fef2f2; color: #ef4444; }
    .btn-hapus:hover { background: #ef4444; color: white; }

    .empty-state {
        text-align: center;
        padding: 40px 20px !important;
        color: var(--text-muted);
        font-size: 13px;
        font-weight: 500;
    }

    /* RESPONSIVE LAYOUT */
    @media (max-width: 1024px) {
        .main-content { margin-left: 0; width: 100%; padding: 40px 24px 24px 24px; }
        .btn-menu { display: block; }
    }

    @media (max-width: 640px) {
        .topbar { flex-direction: column; align-items: flex-start; gap: 16px; }
        .form-group-premium { flex-direction: column; align-items: stretch; gap: 10px; }
        .input-premium { width: 100%; }
        .input-cari { width: 100%; }
        .cari-filter { flex-direction: column; align-items: stretch; gap: 10px; }
        .btn-utama-premium { justify-content: center; width: 100%; }
        .btn-batal-premium { justify-content: center; width: 100%; }
    }
</style>

<div class="app-wrapper">
    <div id="sidebarOverlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:90"></div>

    <?php include '../../includes/sidebar_admin.php'; ?>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-kiri" style="display:flex; align-items:center;">
                <button class="btn-menu" id="btnMenu">☰</button>
                <div>
                    <div class="topbar-judul">Kelola Kategori</div>
                    <div class="topbar-sub">Manajemen klasifikasi dan pengelompokan opsi kegiatan sistem</div>
                </div>
            </div>
        </div>

        <div class="page-content">
            <?php tampilkanFlash(); ?>
            
            <div class="card">
                <div class="card-header-inline">
                    <span style="font-size: 16px;"><?= $is_edit ? '✏️' : '✨' ?></span>
                    <h3 class="card-judul-inline">
                        <?= $is_edit ? 'Modifikasi Dokumen Kategori' : 'Tambah Format Kategori Baru' ?>
                    </h3>
                </div>
                
                <form method="POST" action="kategori.php">
                    <input type="hidden" name="id_kategori" value="<?= $id_edit ?>">
                    <div class="form-group-premium">
                        <input type="text" class="input-premium" name="nama_kategori" 
                               placeholder="Contoh: Seminar, Workshop, Lomba Akademik..." 
                               value="<?= htmlspecialchars($nama_kategori_val) ?>" required>
                        
                        <button type="submit" name="simpan_kategori" class="btn-utama-premium">
                            <span><?= $is_edit ? 'Simpan Perubahan' : 'Simpan Kategori' ?></span>
                        </button>
                        
                        <?php if ($is_edit): ?>
                            <a href="kategori.php" class="btn-batal-premium">Batal</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <form method="GET" action="">
                    <div class="cari-filter">
                        <input type="text" class="input-cari" name="cari" placeholder="Cari nama kategori..." value="<?= htmlspecialchars($cari) ?>">
                        <button type="submit" class="btn-utama-premium">
                            <span>🔍 Cari</span>
                        </button>
                    </div>
                </form>
                
                <div class="tabel-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 80px; text-align: center;">No</th>
                                <th>Nama Kategori Event</th>
                                <th style="width: 140px; text-align: center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($list_kategori) === 0): ?>
                                <tr>
                                    <td colspan="3" class="empty-state">
                                        Belum ada data klasifikasi kategori yang terdaftar.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php $no = $offset + 1; while ($row = mysqli_fetch_assoc($list_kategori)): ?>
                                <tr>
                                    <td style="text-align: center; font-weight: 600; color: var(--text-muted);"><?= $no++ ?></td>
                                    <td>
                                        <div style="font-weight: 600; color: var(--text-dark);"><?= htmlspecialchars($row['nama_kategori']) ?></div>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 8px; justify-content: center;">
                                            <a href="?aksi=edit&id=<?= $row['id_kategori'] ?>" class="btn-aksi btn-edit" title="Ubah Format">✏️</a>
                                            <a href="#" onclick="konfirmasiHapus('?aksi=hapus&id=<?= $row['id_kategori'] ?>', 'kategori ini')" class="btn-aksi btn-hapus" title="Hapus Permanen">🗑️</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_hal > 1): ?>
                <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                    <div style="display: flex; gap: 6px;">
                        <?php for($i = 1; $i <= $total_hal; $i++): ?>
                            <a href="?cari=<?= urlencode($cari) ?>&hal=<?= $i ?>" 
                               class="btn-utama-premium" 
                               style="height: 34px; width: 34px; padding: 0; font-size: 13px; text-decoration: none; box-shadow: none;
                                      display: flex; align-items: center; justify-content: center;
                                      background: <?= $hal_ini === $i ? 'linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%)' : '#ffffff' ?>; 
                                      color: <?= $hal_ini === $i ? '#ffffff' : 'var(--text-dark)' ?>;
                                      border: 1px solid <?= $hal_ini === $i ? 'var(--royal-blue)' : 'var(--border-color)' ?>;
                                      border-radius: 8px;">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </main>
</div>

<script>
    // RESPONSIVE SIDEBAR TOGGLE SCRIPT
    const btnMenu = document.getElementById('btnMenu');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if(btnMenu && sidebar && overlay) {
        btnMenu.addEventListener('click', () => {
            sidebar.style.transform = 'translateX(0)';
            sidebar.style.left = '0';
            overlay.style.display = 'block';
        });

        overlay.addEventListener('click', () => {
            sidebar.style.transform = 'translateX(-100%)';
            overlay.style.display = 'none';
        });
    }
</script>

<?php include '../../includes/footer.php'; ?>