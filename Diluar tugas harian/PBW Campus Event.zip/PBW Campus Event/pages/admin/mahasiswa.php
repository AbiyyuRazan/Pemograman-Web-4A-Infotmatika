<?php
// ============================================
// pages/admin/mahasiswa.php — Lihat Data Mahasiswa (Perfect Spacing Edition)
// ============================================
session_start();
require_once '../../config/koneksi.php';
require_once '../../includes/functions.php';
wajibAdmin();

$judul_halaman = 'Data Mahasiswa';
$halaman_aktif = 'mahasiswa';

$cari         = bersihkan($_GET['cari'] ?? '');
$filter_prodi = bersihkan($_GET['prodi'] ?? '');
$per_halaman  = 10;
$hal_ini      = max(1, (int)($_GET['hal'] ?? 1));
$offset       = ($hal_ini - 1) * $per_halaman;

$where = "WHERE 1=1";
if ($cari)         $where .= " AND (pm.nama_lengkap LIKE '%$cari%' OR pm.nim LIKE '%$cari%')";
if ($filter_prodi) $where .= " AND pm.prodi='$filter_prodi'";

$total_rows = mysqli_fetch_assoc(mysqli_query($koneksi,
    "SELECT COUNT(*) as total FROM profil_mahasiswa pm $where"))['total'];
$total_hal = ceil($total_rows / $per_halaman);

$list = mysqli_query($koneksi,
    "SELECT pm.*, u.username, u.created_at,
            COUNT(r.id_registrasi) as total_registrasi
     FROM profil_mahasiswa pm
     JOIN users u ON pm.id_user = u.id_user
     LEFT JOIN registrasi r ON pm.id_mahasiswa = r.id_mahasiswa
     $where
     GROUP BY pm.id_mahasiswa
     ORDER BY pm.nama_lengkap
     LIMIT $per_halaman OFFSET $offset"
);

// Ambil daftar prodi untuk filter dropdown
$list_prodi = mysqli_query($koneksi,
    "SELECT DISTINCT prodi FROM profil_mahasiswa ORDER BY prodi");
?>
<?php include '../../includes/header.php'; ?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --royal-blue: #1d4ed8;       
        --deep-blue: #1e40af;        
        --bg-dashboard: #f8fafc;     
        --text-dark: #0f172a;        
        --text-muted: #64748b;       
        --border-color: #e2e8f0;     
    }

    /* OVERRIDE & RESET CONTAINER UTAMA STYLING */
    body {
        background-color: var(--bg-dashboard);
        margin: 0;
    }

    .app-wrapper {
        background-color: var(--bg-dashboard);
        min-height: 100vh;
        display: flex;
    }

    .main-content {
        margin-left: 260px; 
        width: calc(100% - 260px);
        padding: 60px 40px 40px 40px; 
        background-color: var(--bg-dashboard);
        min-height: 100vh;
        box-sizing: border-box;
        transition: all 0.3s ease;
    }

    .main-content * {
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    /* --- TOPBAR AREA --- */
    .topbar {
        display: flex;
        justify-content: space-between;
        align-items: center; 
        padding-bottom: 24px; 
        margin-bottom: 36px;  
        border-bottom: 2px solid var(--border-color); 
        background: transparent;
    }

    .topbar-judul {
        font-size: 28px; 
        font-weight: 800; 
        color: var(--text-dark);
        letter-spacing: -0.75px;
        line-height: 1.2;
    }

    .topbar-sub {
        font-size: 14px;
        color: var(--text-muted);
        margin-top: 6px;
        font-weight: 500;
    }

    .btn-menu {
        display: none;
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: var(--text-dark);
        margin-right: 14px;
        padding: 0;
    }

    /* --- CARD CONTAINER PREMIUM --- */
    .card {
        background: #ffffff;
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 24px;
        box-shadow: 0 4px 10px rgba(15, 23, 42, 0.01);
    }

    .card-header-inline {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid #f1f5f9;
    }

    .card-judul-inline {
        margin: 0; 
        font-size: 16px; 
        font-weight: 700; 
        color: var(--text-dark);
    }

    /* --- COMPONENT CARI & FILTER INLINE --- */
    .cari-filter {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
    }

    .input-cari {
        height: 42px;
        padding: 0 16px;
        font-size: 14px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        color: var(--text-dark);
        background-color: #ffffff;
        width: 280px;
        transition: all 0.2s ease;
    }

    .input-cari:focus {
        outline: none;
        border-color: var(--royal-blue);
        box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.15);
    }

    .select-premium {
        height: 42px;
        padding: 0 36px 0 16px;
        font-size: 14px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        color: var(--text-dark);
        background-color: #ffffff;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .select-premium:focus {
        outline: none;
        border-color: var(--royal-blue);
    }

    .btn-cari-premium {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        height: 42px;
        padding: 0 22px;
        background: linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%);
        color: #ffffff;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px; 
        border: none;
        box-shadow: 0 4px 14px rgba(29, 78, 216, 0.25);
        transition: all 0.2s ease;
        cursor: pointer;
    }

    .btn-cari-premium:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(29, 78, 216, 0.35);
    }

    .btn-batal-premium {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 42px;
        padding: 0 20px;
        background: #f1f5f9;
        color: #475569;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px;
        transition: all 0.2s;
    }

    .btn-batal-premium:hover {
        background: #e2e8f0;
        color: #1e293b;
    }

    /* --- TABEL PRESET SYSTEM --- */
    .tabel-wrapper {
        overflow-x: auto;
    }

    .tabel-wrapper table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
    }

    .tabel-wrapper th {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-muted);
        padding: 12px 14px;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #f1f5f9;
    }

    .tabel-wrapper td {
        padding: 16px 14px;
        font-size: 13.5px;
        color: var(--text-dark);
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
    }

    .tabel-wrapper tr:last-child td {
        border-bottom: none;
    }

    .tabel-wrapper tbody tr:hover {
        background-color: #f8fafc;
    }

    /* AVATAR SYSTEM */
    .avatar-circle {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: var(--royal-blue);
        color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 13px;
        flex-shrink: 0;
    }

    /* BADGE LENCANA INFO */
    .badge-info-premium {
        background-color: #e0f2fe;
        color: #0369a1;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        display: inline-block;
        white-space: nowrap;
    }

    .empty-state {
        text-align: center;
        padding: 40px 20px !important;
        color: var(--text-muted);
        font-size: 13px;
        font-weight: 500;
    }

    /* RESPONSIVE LAYOUT */
    @media (max-width: 1024px) {
        .main-content { margin-left: 0; width: 100%; padding: 40px 24px 24px 24px; }
        .btn-menu { display: block; }
    }

    @media (max-width: 640px) {
        .topbar { flex-direction: column; align-items: flex-start; gap: 16px; }
        .input-cari { width: 100%; }
        .select-premium { width: 100%; }
        .btn-cari-premium { width: 100%; justify-content: center; }
        .btn-batal-premium { width: 100%; justify-content: center; }
    }
</style>

<div class="app-wrapper">
    <div id="sidebarOverlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:90"></div>

    <?php include '../../includes/sidebar_admin.php'; ?>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-kiri" style="display:flex; align-items:center;">
                <button class="btn-menu" id="btnMenu">☰</button>
                <div>
                    <div class="topbar-judul">Data Mahasiswa</div>
                    <div class="topbar-sub">Arsip dan direktori database pengguna mahasiswa terdaftar sistem</div>
                </div>
            </div>
        </div>

        <div class="page-content">
            <?php tampilkanFlash(); ?>
            
            <div class="card">
                <div class="card-header-inline">
                    <span style="font-size: 16px;"></span>
                    <h3 class="card-judul-inline">Direktori Mahasiswa (<?= number_format($total_rows) ?>)</h3>
                </div>

                <form method="GET">
                    <div class="cari-filter">
                        <input type="text" class="input-cari" name="cari" placeholder="Cari nama atau NIM..." value="<?= htmlspecialchars($cari) ?>">
                        
                        <select name="prodi" class="select-premium">
                            <option value="">Semua Program Studi</option>
                            <?php while ($p = mysqli_fetch_assoc($list_prodi)): ?>
                                <option value="<?= htmlspecialchars($p['prodi']) ?>" <?= $filter_prodi === $p['prodi'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($p['prodi']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        
                        <button type="submit" class="btn-cari-premium">
                            <span>Cari</span>
                        </button>
                        
                        <a href="mahasiswa.php" class="btn-batal-premium">Reset</a>
                    </div>
                </form>

                <div class="tabel-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 60px; text-align: center;">No</th>
                                <th>Nama Lengkap</th>
                                <th>NIM</th>
                                <th>Program Studi</th>
                                <th>Email Berkas</th>
                                <th>Username</th>
                                <th style="text-align: center;">Aktivitas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($list) === 0): ?>
                            <tr>
                                <td colspan="7" class="empty-state">
                                    Tidak ditemukan arsip data mahasiswa yang sesuai dengan pencarian.
                                </td>
                            </tr>
                            <?php else: $no = $offset + 1; while ($row = mysqli_fetch_assoc($list)): ?>
                            <tr>
                                <td style="text-align: center; font-weight: 600; color: var(--text-muted);"><?= $no++ ?></td>
                                <td>
                                    <div style="display:flex; align-items:center; gap:12px">
                                        <div class="avatar-circle">
                                            <?= strtoupper(substr($row['nama_lengkap'], 0, 1)) ?>
                                        </div>
                                        <span style="font-weight:600; color:var(--text-dark)"><?= htmlspecialchars($row['nama_lengkap']) ?></span>
                                    </div>
                                </td>
                                <td>
                                    <code style="font-size:12px; font-weight: 600; color: #334155; background: #f1f5f9; padding: 2px 6px; border-radius: 6px;"><?= htmlspecialchars($row['nim']) ?></code>
                                </td>
                                <td>
                                    <span style="font-weight: 500; color: var(--text-dark);"><?= htmlspecialchars($row['prodi']) ?></span>
                                </td>
                                <td>
                                    <span style="color: var(--text-muted); font-size: 13px; font-weight: 400;"><?= htmlspecialchars($row['email']) ?></span>
                                </td>
                                <td>
                                    <span style="color: var(--text-dark); font-weight: 500;"><?= htmlspecialchars($row['username']) ?></span>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge-info-premium">
                                        <?= $row['total_registrasi'] ?> Event Diikuti
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_hal > 1): ?>
                <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                    <div style="display: flex; gap: 6px;">
                        <?php for($i = 1; $i <= $total_hal; $i++): ?>
                            <a href="?hal=<?= $i ?>&cari=<?= urlencode($cari) ?>&prodi=<?= urlencode($filter_prodi) ?>" 
                               class="btn-cari-premium" 
                               style="height: 34px; width: 34px; padding: 0; font-size: 13px; text-decoration: none; box-shadow: none;
                                      display: flex; align-items: center; justify-content: center;
                                      background: <?= $hal_ini === $i ? 'linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%)' : '#ffffff' ?>; 
                                      color: <?= $hal_ini === $i ? '#ffffff' : 'var(--text-dark)' ?>;
                                      border: 1px solid <?= $hal_ini === $i ? 'var(--royal-blue)' : 'var(--border-color)' ?>;
                                      border-radius: 8px;">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </main>
</div>

<script>
    // RESPONSIVE SIDEBAR TOGGLE SCRIPT
    const btnMenu = document.getElementById('btnMenu');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if(btnMenu && sidebar && overlay) {
        btnMenu.addEventListener('click', () => {
            sidebar.style.transform = 'translateX(0)';
            sidebar.style.left = '0';
            overlay.style.display = 'block';
        });

        overlay.addEventListener('click', () => {
            sidebar.style.transform = 'translateX(-100%)';
            overlay.style.display = 'none';
        });
    }
</script>

<?php include '../../includes/footer.php'; ?>