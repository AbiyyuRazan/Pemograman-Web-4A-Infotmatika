<?php
// ============================================
// pages/admin/registrasi.php — Kelola Registrasi (Perfect Spacing Edition)
// ============================================
session_start();
require_once '../../config/koneksi.php';
require_once '../../includes/functions.php';
wajibAdmin();

$judul_halaman = 'Kelola Registrasi';
$halaman_aktif = 'registrasi';
$admin_org = $_SESSION['organisasi'] ?? 'Pusat';

// Update status registrasi
if (isset($_GET['aksi']) && $_GET['aksi'] === 'update_status') {
    $id  = (int)$_GET['id'];
    $sts = bersihkan($_GET['status'] ?? '');
    
    // Cek apakah event ini milik admin yg login
    $cek = mysqli_query($koneksi, "SELECT r.id_registrasi FROM registrasi r JOIN event e ON r.id_event = e.id_event WHERE r.id_registrasi=$id AND (e.penyelenggara='$admin_org' OR '$admin_org'='Pusat')");
    
    if (in_array($sts, ['confirmed', 'pending', 'cancelled']) && mysqli_num_rows($cek) > 0) {
        mysqli_query($koneksi, "UPDATE registrasi SET status='$sts' WHERE id_registrasi=$id");
        redirectDenganPesan('registrasi.php', 'Status registrasi berhasil diperbarui!');
    } else {
        redirectDenganPesan('registrasi.php', 'Gagal! Anda tidak berhak mengubah data ini.', 'error');
    }
}

// Hapus registrasi
if (isset($_GET['aksi']) && $_GET['aksi'] === 'hapus') {
    $id = (int)$_GET['id'];
    $cek = mysqli_query($koneksi, "SELECT r.id_registrasi FROM registrasi r JOIN event e ON r.id_event = e.id_event WHERE r.id_registrasi=$id AND (e.penyelenggara='$admin_org' OR '$admin_org'='Pusat')");
    if (mysqli_num_rows($cek) > 0) {
        mysqli_query($koneksi, "DELETE FROM registrasi WHERE id_registrasi=$id");
        redirectDenganPesan('registrasi.php', 'Registrasi berhasil dihapus.');
    }
}

// Pencarian & Filter
$cari          = bersihkan($_GET['cari'] ?? '');
$filter_status = bersihkan($_GET['status'] ?? '');
$per_halaman   = 12;
$hal_ini       = max(1, (int)($_GET['hal'] ?? 1));
$offset        = ($hal_ini - 1) * $per_halaman;

$where = "WHERE (e.penyelenggara='$admin_org' OR '$admin_org'='Pusat')";
if ($cari)          $where .= " AND (pm.nama_lengkap LIKE '%$cari%' OR pm.nim LIKE '%$cari%' OR e.nama_event LIKE '%$cari%')";
if ($filter_status) $where .= " AND r.status='$filter_status'";

$total_rows = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM registrasi r JOIN profil_mahasiswa pm ON r.id_mahasiswa = pm.id_mahasiswa JOIN event e ON r.id_event = e.id_event $where"))['total'];
$total_hal = ceil($total_rows / $per_halaman);

$list_reg = mysqli_query($koneksi,
    "SELECT r.*, pm.nama_lengkap, pm.nim, e.nama_event, e.jenis_tiket 
     FROM registrasi r 
     JOIN profil_mahasiswa pm ON r.id_mahasiswa = pm.id_mahasiswa 
     JOIN event e ON r.id_event = e.id_event 
     $where 
     ORDER BY r.tanggal_registrasi DESC, r.id_registrasi DESC 
     LIMIT $per_halaman OFFSET $offset"
);
?>
<?php include '../../includes/header.php'; ?>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
    :root {
        --royal-blue: #1d4ed8;       
        --deep-blue: #1e40af;        
        --bg-dashboard: #f8fafc;     
        --text-dark: #0f172a;        
        --text-muted: #64748b;       
        --border-color: #e2e8f0;     
    }

    /* OVERRIDE & RESET CONTAINER UTAMA STYLING */
    body {
        background-color: var(--bg-dashboard);
        margin: 0;
    }

    .app-wrapper {
        background-color: var(--bg-dashboard);
        min-height: 100vh;
        display: flex;
    }

    .main-content {
        margin-left: 260px; 
        width: calc(100% - 260px);
        padding: 60px 40px 40px 40px; 
        background-color: var(--bg-dashboard);
        min-height: 100vh;
        box-sizing: border-box;
        transition: all 0.3s ease;
    }

    .main-content * {
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    /* --- TOPBAR AREA --- */
    .topbar {
        display: flex;
        justify-content: space-between;
        align-items: center; 
        padding-bottom: 24px; 
        margin-bottom: 36px;  
        border-bottom: 2px solid var(--border-color); 
        background: transparent;
    }

    .topbar-judul {
        font-size: 28px; 
        font-weight: 800; 
        color: var(--text-dark);
        letter-spacing: -0.75px;
        line-height: 1.2;
    }

    .topbar-sub {
        font-size: 14px;
        color: var(--text-muted);
        margin-top: 6px;
        font-weight: 500;
    }

    .btn-menu {
        display: none;
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: var(--text-dark);
        margin-right: 14px;
        padding: 0;
    }

    /* --- CARD CONTAINER PREMIUM --- */
    .card {
        background: #ffffff;
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 24px;
        box-shadow: 0 4px 10px rgba(15, 23, 42, 0.01);
    }

    /* --- COMPONENT CARI & FILTER INLINE --- */
    .cari-filter {
        display: flex;
        gap: 12px;
        align-items: center;
        margin-bottom: 24px;
        flex-wrap: wrap;
    }

    .input-cari {
        height: 42px;
        padding: 0 16px;
        font-size: 14px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        color: var(--text-dark);
        background-color: #ffffff;
        width: 280px;
        transition: all 0.2s ease;
    }

    .input-cari:focus {
        outline: none;
        border-color: var(--royal-blue);
        box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.15);
    }

    .select-premium {
        height: 42px;
        padding: 0 36px 0 16px;
        font-size: 14px;
        border-radius: 10px;
        border: 1px solid var(--border-color);
        color: var(--text-dark);
        background-color: #ffffff;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .select-premium:focus {
        outline: none;
        border-color: var(--royal-blue);
    }

    .btn-cari-premium {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        height: 42px;
        padding: 0 22px;
        background: linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%);
        color: #ffffff;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        border-radius: 10px; 
        border: none;
        box-shadow: 0 4px 14px rgba(29, 78, 216, 0.25);
        transition: all 0.2s ease;
        cursor: pointer;
    }

    .btn-cari-premium:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(29, 78, 216, 0.35);
    }

    /* --- TABEL PRESET SYSTEM --- */
    .tabel-wrapper {
        overflow-x: auto;
    }

    .tabel-wrapper table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
    }

    .tabel-wrapper th {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: var(--text-muted);
        padding: 12px 14px;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #f1f5f9;
    }

    .tabel-wrapper td {
        padding: 16px 14px;
        font-size: 13.5px;
        color: var(--text-dark);
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
    }

    .tabel-wrapper tr:last-child td {
        border-bottom: none;
    }

    .tabel-wrapper tbody tr:hover {
        background-color: #f8fafc;
    }

    /* INTERCEPT BADGE STATUS RE-STYLE */
    .badge, [class*="badge-"], [class*="status-"] {
        display: inline-flex !important;
        align-items: center;
        padding: 4px 10px !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        border-radius: 8px !important;
        text-transform: capitalize !important;
        border: none !important;
    }
    .badge-success, .status-published, .status-confirmed, .badge-aktif { background: #d1fae5 !important; color: #065f46 !important; }
    .badge-warning, .status-draft, .badge-pending { background: #fef3c7 !important; color: #92400e !important; }
    .badge-danger, .status-cancelled { background: #fee2e2 !important; color: #991b1b !important; }

    /* ACTION BUTTONS DESIGN */
    .btn-aksi {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.2s ease;
        font-size: 12px;
        border: none;
        cursor: pointer;
    }
    .btn-terima { background: #ecfdf5; color: #10b981; }
    .btn-terima:hover { background: #10b981; color: white; }
    .btn-tolak { background: #fef2f2; color: #ef4444; }
    .btn-tolak:hover { background: #ef4444; color: white; }
    .btn-hapus { background: #f1f5f9; color: #64748b; }
    .btn-hapus:hover { background: #64748b; color: white; }

    .empty-state {
        text-align: center;
        padding: 40px 20px !important;
        color: var(--text-muted);
        font-size: 13px;
        font-weight: 500;
    }

    /* RESPONSIVE LAYOUT */
    @media (max-width: 1024px) {
        .main-content { margin-left: 0; width: 100%; padding: 40px 24px 24px 24px; }
        .btn-menu { display: block; }
    }

    @media (max-width: 640px) {
        .topbar { flex-direction: column; align-items: flex-start; gap: 16px; }
        .input-cari { width: 100%; }
        .select-premium { width: 100%; }
        .btn-cari-premium { width: 100%; justify-content: center; }
    }
</style>

<div class="app-wrapper">
    <div id="sidebarOverlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:90"></div>

    <?php include '../../includes/sidebar_admin.php'; ?>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-kiri" style="display:flex; align-items:center;">
                <button class="btn-menu" id="btnMenu">☰</button>
                <div>
                    <div class="topbar-judul">Kelola Pendaftar</div>
                    <div class="topbar-sub">Kelola registrasi peserta masuk <?= $admin_org !== 'Pusat' ? "($admin_org)" : '' ?></div>
                </div>
            </div>
        </div>

        <div class="page-content">
            <?php tampilkanFlash(); ?>
            
            <div class="card">
                <form method="GET" action="">
                    <div class="cari-filter">
                        <input type="text" class="input-cari" name="cari" placeholder="Cari nama, NIM, atau event..." value="<?= htmlspecialchars($cari) ?>">
                        
                        <select name="status" class="select-premium">
                            <option value="">Semua Status</option>
                            <option value="pending" <?= $filter_status === 'pending' ? 'selected' : '' ?>>⏳ Pending</option>
                            <option value="confirmed" <?= $filter_status === 'confirmed' ? 'selected' : '' ?>>✔️ Confirmed</option>
                            <option value="cancelled" <?= $filter_status === 'cancelled' ? 'selected' : '' ?>>❌ Cancelled</option>
                        </select>
                        
                        <button type="submit" class="btn-cari-premium">
                            <span>🔍 Cari Data</span>
                        </button>
                    </div>
                </form>

                <div class="tabel-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 60px; text-align: center;">No</th>
                                <th>Mahasiswa</th>
                                <th>Event & Tiket</th>
                                <th>Tanggal & Bukti</th>
                                <th style="width: 140px; text-align: center;">Status</th>
                                <th style="width: 140px; text-align: center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($list_reg) === 0): ?>
                            <tr>
                                <td colspan="6" class="empty-state">
                                    Tidak ada data registrasi peserta yang ditemukan.
                                </td>
                            </tr>
                            <?php else: $no = $offset + 1; while ($row = mysqli_fetch_assoc($list_reg)): ?>
                            <tr>
                                <td style="text-align: center; font-weight: 600; color: var(--text-muted);"><?= $no++ ?></td>
                                <td>
                                    <span style="font-weight:600; color:var(--text-dark)"><?= htmlspecialchars($row['nama_lengkap']) ?></span><br>
                                    <small style="color:var(--text-muted); font-size:11px; font-weight: 500;"><?= htmlspecialchars($row['nim']) ?></small>
                                </td>
                                <td>
                                    <span style="font-weight:500; color:var(--text-dark)"><?= htmlspecialchars($row['nama_event']) ?></span><br>
                                    <small style="color: var(--royal-blue); font-weight: 700; font-size: 11px; text-transform: uppercase;"><?= htmlspecialchars($row['jenis_tiket']) ?></small>
                                </td>
                                <td>
                                    <small style="color: #475569; font-weight: 500;"><?= formatTanggal($row['tanggal_registrasi']) ?></small><br>
                                    <?php if ($row['bukti_pembayaran']): ?>
                                        <a href="../../assets/img/bukti/<?= $row['bukti_pembayaran'] ?>" target="_blank" style="font-size:11px; color:#10b981; font-weight:600; text-decoration:none; display:inline-flex; align-items:center; gap:3px; margin-top:2px;">
                                            📄 Lihat Bukti Bayar
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <?= badgeStatus($row['status']) ?>
                                </td>
                                <td>
                                    <div style="display:flex; gap:6px; justify-content: center;">
                                        <?php if ($row['status'] === 'pending'): ?>
                                            <a href="?aksi=update_status&id=<?= $row['id_registrasi'] ?>&status=confirmed" class="btn-aksi btn-terima" title="Terima Pendaftaran">✔️</a>
                                            <a href="?aksi=update_status&id=<?= $row['id_registrasi'] ?>&status=cancelled" class="btn-aksi btn-tolak" title="Tolak Pendaftaran">❌</a>
                                        <?php endif; ?>
                                        <a href="#" onclick="konfirmasiHapus('?aksi=hapus&id=<?= $row['id_registrasi'] ?>', 'registrasi ini')" class="btn-aksi btn-hapus" title="Hapus Data">🗑️</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_hal > 1): ?>
                <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                    <div style="display: flex; gap: 6px;">
                        <?php for($i = 1; $i <= $total_hal; $i++): ?>
                            <a href="?cari=<?= urlencode($cari) ?>&status=<?= urlencode($filter_status) ?>&hal=<?= $i ?>" 
                               class="btn-cari-premium" 
                               style="height: 34px; width: 34px; padding: 0; font-size: 13px; text-decoration: none; box-shadow: none;
                                      display: flex; align-items: center; justify-content: center;
                                      background: <?= $hal_ini === $i ? 'linear-gradient(135deg, var(--royal-blue) 0%, var(--deep-blue) 100%)' : '#ffffff' ?>; 
                                      color: <?= $hal_ini === $i ? '#ffffff' : 'var(--text-dark)' ?>;
                                      border: 1px solid <?= $hal_ini === $i ? 'var(--royal-blue)' : 'var(--border-color)' ?>;
                                      border-radius: 8px;">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </main>
</div>

<script>
    // RESPONSIVE SIDEBAR TOGGLE SCRIPT
    const btnMenu = document.getElementById('btnMenu');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    if(btnMenu && sidebar && overlay) {
        btnMenu.addEventListener('click', () => {
            sidebar.style.transform = 'translateX(0)';
            sidebar.style.left = '0';
            overlay.style.display = 'block';
        });

        overlay.addEventListener('click', () => {
            sidebar.style.transform = 'translateX(-100%)';
            overlay.style.display = 'none';
        });
    }
</script>

<?php include '../../includes/footer.php'; ?>